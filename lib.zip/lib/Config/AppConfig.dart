import 'package:flutter/material.dart';

class AppConfig {
  static String appName = "Easy Transfer";
  static String? UserId;
}
