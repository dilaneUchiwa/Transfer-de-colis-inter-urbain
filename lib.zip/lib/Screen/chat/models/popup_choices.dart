import 'package:flutter/material.dart';

class PopupChoices {
  final String title;
  final IconData icon;

  const PopupChoices({required this.title, required this.icon});
}
